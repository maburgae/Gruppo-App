
import streamlit as st
import importlib

st.set_page_config(page_title="Gruppo App", page_icon="⛳", layout="wide")

# --- Simple responsive top bar with 4 buttons ---
TOP_PAGES = ["Runden", "Stats", "2025", "Konf"]

# Minimal mobile-friendly styles
st.markdown("""
<style>
/* Remove Streamlit's default top margin/padding */
.main .block-container {
    padding-top: 0rem !important;
    margin-top: 0rem !important;
}

/* Also collapse spacing above the first element */
section[data-testid="stSidebar"] > div:first-child,
div[data-testid="stToolbar"] {
    margin-top: 0 !important;
    padding-top: 0 !important;
}
</style>
""", unsafe_allow_html=True)



if "active_tab" not in st.session_state:
    st.session_state.active_tab = "Runden"

# mapping page name -> module path
MODULES = {
    "Runden": "pages.runden",
    "Stats": "pages.stats",
    "2025": "pages.y2025",
    "Konf": "pages.konf",
}

def nav_button(label: str):
    # Render a button that sets the active tab
    is_active = (st.session_state.active_tab == label)
    btn_ph = st.container()
    with btn_ph:
        # Use unique keys
        if st.button(label, key=f"tab_{label}"):
            st.session_state.active_tab = label
    # Add a subtle active style (optional)
    if is_active:
        st.markdown("<div class='active-tab' style='height:1px'></div>", unsafe_allow_html=True)

# --- Topbar ---
with st.container():
    st.markdown("<div class='topbar'><div class='btnrow'>", unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns(4, gap="small")
    with col1: nav_button("Runden")
    with col2: nav_button("Stats")
    with col3: nav_button("2025")
    with col4: nav_button("Konf")
    st.markdown("</div></div>", unsafe_allow_html=True)


# --- Load and render the active page ---
active = st.session_state.active_tab
module_path = MODULES.get(active, "pages.runden")
page_module = importlib.import_module(module_path)

# Each page exposes a render(st) function
if hasattr(page_module, "render") and callable(page_module.render):
    page_module.render(st)
else:
    st.error(f"Seite '{active}' hat keine gültige render(st)-Funktion.")
