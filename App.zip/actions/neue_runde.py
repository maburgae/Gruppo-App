
def main(players: list[str] | None = None) -> str:
    """Startet eine neue Runde. Platzhalter-Logik."""
    if players is None:
        players = []
    return f"Neue Runde gestartet. Spieler: {players}"
