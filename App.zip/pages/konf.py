
import json
import pandas as pd

from actions.neue_runde import main as neue_runde_main
from actions.upload_scorecard import main as upload_scorecard_main
from actions.berechne_den_tag import main as berechne_den_tag_main
from actions.tag_to_alle_runden import main as tag_to_alle_runden_main
from actions.erzeuge_stats import main as erzeuge_stats_main

DEFAULT_PLAYERS_STR = '["Marc","Andy","Bernie","Jens","Heiko","Markus","Buffy"]'

def _init_state():
    import streamlit as st
    if "konf_players" not in st.session_state:
        st.session_state.konf_players = DEFAULT_PLAYERS_STR
    if "konf_file_id" not in st.session_state:
        st.session_state.konf_file_id = ""
    if "konf_output" not in st.session_state:
        st.session_state.konf_output = ""
    if "golf_df" not in st.session_state:
        st.session_state.golf_df = pd.DataFrame({
            "Hole": list(range(1, 7)),
            "Par": [4,4,5,3,4,5],
            "Hcp": [9,7,11,15,13,17]
        })

def render(st):
    _init_state()

    st.header("Konfiguration")

    # Knopf "Neue Runde"
    if st.button("Neue Runde"):
        try:
            players = json.loads(st.session_state.konf_players)
            if not isinstance(players, list):
                raise ValueError("Spieler muss eine JSON-Liste sein.")
        except Exception as e:
            st.session_state.konf_output = f"Fehler: Ungültiges Spieler-Format: {e}"
        else:
            result = neue_runde_main(players)
            st.session_state.konf_output = result

    # Eingabefeld "Spieler"
    st.text_input("Spieler (JSON-Liste)", value=st.session_state.konf_players, key="konf_players")

    # Knopf "Upload Scorecard"
    if st.button("Upload Scorecard"):
        result = upload_scorecard_main(st.session_state.konf_file_id)
        st.session_state.konf_output = result

    # Eingabefeld "File-ID"
    st.text_input("File-ID", value=st.session_state.konf_file_id, key="konf_file_id")

    # Editierbare Tabelle "golf_df"
    st.subheader("golf_df")
    st.session_state.golf_df = st.data_editor(st.session_state.golf_df, key="golf_df_editor", width='stretch')

    # Knopf "Berechne den Tag"
    if st.button("Berechne den Tag"):
        result = berechne_den_tag_main(st.session_state.golf_df)
        st.session_state.konf_output = result

    # Show a picture (2x)
    st.image("assets/placeholder_1.png", caption="Bild 1", width='stretch')
    st.image("assets/placeholder_2.png", caption="Bild 2", width='stretch')

    # Knopf: "Tag -> Alle Runden"
    if st.button("Tag -> Alle Runden"):
        result = tag_to_alle_runden_main()
        st.session_state.konf_output = result

    # Knopf: "Erzeuge Stats"
    if st.button("Erzeuge Stats"):
        result = erzeuge_stats_main()
        st.session_state.konf_output = result

    # Ausgabefeld "Output"
    st.subheader("Output")
    st.text_area("Ausgabe", value=st.session_state.konf_output, key="konf_output_area", height=120)
